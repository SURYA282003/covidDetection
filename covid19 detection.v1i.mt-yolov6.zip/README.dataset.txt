# covid19 detection > 2023-09-26 12:42pm
https://universe.roboflow.com/tru-project-qvb6r/covid19-detection

Provided by a Roboflow user
License: CC BY 4.0

