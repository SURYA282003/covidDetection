# covid or noncovid > 2023-07-09 3:31pm
https://universe.roboflow.com/lds8-q2ey0/covid-or-noncovid

Provided by a Roboflow user
License: CC BY 4.0

